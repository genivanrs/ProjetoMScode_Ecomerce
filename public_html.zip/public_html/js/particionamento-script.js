src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
$(function(){                       
   $('#section').load("section/section.html"); /*chama o codigo section*/ 
   $('#footer').load("footer.html"); /*chama o codigo footer*/ 
   $('#header').load("header.html"); /*chama o codigo header*/                                       
   });
   /*Teste para ver se o JQuery esta funcionando*/
   $(document).ready(function() {
      console.log("jQuery está funcionando!");
  });   


