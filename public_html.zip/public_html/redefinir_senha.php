<!DOCTYPE html>
<html>
<head>
    <title>Redefinir Minha Senha</title>
</head>
<body>
    <h1>Redefinir Minha Senha</h1>
    <form action="processar_redefinicao_senha.php" method="post">
        <label for="nova_senha">Nova Senha:</label>
        <input type="password" name="nova_senha" id="nova_senha" required>
        <input type="hidden" name="token" value="<?php echo $_GET['token']; ?>">
        <input type="submit" value="Redefinir Senha">
    </form>
</body>
</html>
