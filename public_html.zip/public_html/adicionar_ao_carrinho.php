<?php
// Inicie a sessão (se ainda não estiver iniciada)
session_start();

// Verifique se o usuário está logado 
// Se não estiver logado, redirecione para a página de login
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

// Conecte-se ao banco de dados (substitua com suas credenciais)
include('config.php');

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifique a conexão
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Obtém o ID do usuário logado
$usuario_id = $_SESSION['usuario_id'];

// Consulta SQL para obter os pedidos do usuário
$sql = "SELECT * FROM pedidos WHERE cliente_id = $usuario_id";
$result = $conn->query($sql);


$id_produto = $_POST['id_produto'];
$descricao = $_POST['descricao'];
$preco = $_POST['preco'];
$userId = $_SESSION['usuario_id'];




// Prepare the insertion
$insert = $conn->prepare("INSERT INTO compras (usuario_id, id_produto, quantidade, descricao, preco) VALUES (?, ?, 1, ?, ?)");
$insert->bind_param("iisd", $usuario_id, $id_produto, $descricao, $preco);

if ($insert->execute()) {
    
} else {
    echo "Error adding the product to the cart: " . $conn->error;
}

$conn->close();
?>

