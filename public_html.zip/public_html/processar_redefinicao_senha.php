<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conecte-se ao banco de dados
    $conexao = new mysqli("localhost", "root", "102030@ABC", "ecomerce");
    if ($conexao->connect_error) {
        die("Falha na conexão: " . $conexao->connect_error);
    }

    // Receba os dados do formulário
    $nova_senha = $conexao->real_escape_string($_POST["nova_senha"]);
    $token = $conexao->real_escape_string($_POST["token"]);

    // Verifique se o token é válido e ainda não expirou
    $sql = "SELECT email FROM senha_reset WHERE token = '$token' AND expiracao >= NOW()";
    $resultado = $conexao->query($sql);

    if ($resultado->num_rows > 0) {
        $row = $resultado->fetch_assoc();
        $email = $row["email"];

        // Atualize a senha no banco de dados
        $senha_hash = password_hash($nova_senha, PASSWORD_BCRYPT);
        $sql = "UPDATE usuarios SET senha = '$senha_hash' WHERE email = '$email'";
        $conexao->query($sql);

        // Remova o token da tabela de redefinição de senha
        $sql = "DELETE FROM senha_reset WHERE token = '$token'";
        $conexao->query($sql);

        echo "Senha redefinida com sucesso. Você pode fazer login com a nova senha.";
    } else {
        echo "O token é inválido ou expirou. Por favor, solicite uma nova redefinição de senha.";
    }

    // Feche a conexão com o banco de dados
    $conexao->close();
}
?>
