<?php
$servername = "localhost";
$username = "id21381713_root";
$password = "102030@ABCabc";
$dbname = "id21381713_ecomerce";

// Estabeleça a conexão com o banco de dados
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifique a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
